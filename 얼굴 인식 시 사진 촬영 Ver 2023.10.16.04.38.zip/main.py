import cv2  # opencv 활용하기 위한 import
import numpy as np
from PIL import Image

pictureTime = 3 # 사진촬영 대기 시간은 3초.

camera = cv2.VideoCapture(0)    # 실행하는 장치의 카메라를 켜고 640 X 480 의 해상도로 설정한다.
camera.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

faceRecognize = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    # 원활한 얼굴 인식을 위해 얼굴 인식 데이터 셋이 필요하기 때문에 Intel Corporation 의
    # haarcascade_frontalface_default.xml 파일을 사용하기로 하였다.

while True:
    isCamera, captured = camera.read()  # 카메라로 captured 에 현재 연상 받아옴.
    grayCamera = cv2.cvtColor(captured, cv2.COLOR_BGR2GRAY) # 카메라로 받아온 영상을 흑백영상으로 바꿈.

    recognizedFaces = faceRecognize.detectMultiScale(grayCamera, scaleFactor=1.01, minNeighbors=100, minSize=(20, 20))
        # scaleFactor 를 1에 가깝게 하면 정확도가 오르지만 처리시간이 길어짐
        # minNeighbors 를 높이면 검출에 있어 좋아지지만 오탐지율도 상승함.

    captured = Image.fromarray(captured)    # 카메라로 촬영되는 영상을 송출할 수 있는 형태로 변환함.
    captured = np.array(captured)

    print(pictureTime)

    if len(recognizedFaces):    # 얼굴이 인식될 때 pictureTime 가 1씩 줄어들고 -1이 되면
        pictureTime -= 1        # Pictured! 문구와 함께 사각형이 빨간색으로 점등하며 사진이 저장된다.

        if pictureTime == -1:
            cv2.imwrite('captured.png', captured)
            for x, y, w, h in recognizedFaces:
                cv2.rectangle(captured, (x, y), (x + w, y + h), (0, 0, 255), 2, cv2.LINE_4)
            cv2.imshow("original", captured)
            print("Pictured!")
            cv2.waitKey(1000)
            pictureTime = 3

    if len(recognizedFaces):    # 얼굴을 인식하면 하얀색 사각형이 얼굴 주변에 위치한다.
        for x, y, w, h in recognizedFaces:
            cv2.rectangle(captured, (x, y), (x + w, y + h), (255, 255, 255), 2, cv2.LINE_4)

    cv2.imshow("original", captured)    # 영상과 사각형이 합쳐진 형태가 송출된다.

    if cv2.waitKey(1000) == ord('q'):   # 1초마다 작업을 반복하고, 'q' 가 눌리는 경우 프로그램이 종료된다.
        break

camera.release()
cv2.destroyAllWindows()